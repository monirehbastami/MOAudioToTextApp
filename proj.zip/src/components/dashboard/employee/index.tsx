import React from 'react';
interface DashboardEmployeeProps extends React.PropsWithChildren{
    
}

const DashboardEmployee: React.FunctionComponent<DashboardEmployeeProps> = () => {
    return ( <>
    DashboardEmployee
    </> );
}

export default DashboardEmployee;